<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Index</title>
    <style>
        .judul {
            font-style: italic;
        }
    </style>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    
    <h1 style="color: yellow;">INI ADALAH HALAMAN INDEX</h1>
    <h2 class="judul">NAMA SAYA adalah {{ $m }}</h2>
    <h2 class="judul1">Umur Saya {{$u}}</h2>
    <h3 class="judul2">JANGAN BUDI YAA TEMAN</h3>
    
<p class="teks"> 
    <b>Lorem ipsum</b> <i>dolor, sit amet consectetur adipisicing elit. Obcaecati fugit omnis consectetur reprehenderit? Rerum modi, itaque quisquam ullam ipsa est aliquid, deleniti sit pariatur odit laudantium qui cum. Cumque, maiores. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Minus ea, molestiae accusamus officia maiores cum id ut quaerat optio asperiores esse facere ab totam deleniti amet velit, voluptatum veniam ullam. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod cum esse ducimus aliquid sed quisquam odit soluta adipisci tempore fugiat quibusdam veritatis voluptates sint, autem ex saepe possimus est cumque. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Molestiae minima facilis adipisci placeat aspernatur porro veritatis aliquam dolorum nisi debitis non et numquam doloremque eius beatae autem laboriosam, maiores officia!</i>
</p>
</body>
</html>